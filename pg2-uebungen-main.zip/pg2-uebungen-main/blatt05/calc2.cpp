//
// Created by Brandon Hernandez on 16.04.24.
//
#include <iostream>
#include <string>
#include "calc.h"
#include <sstream>

using std::cout, std::cerr, std::endl;

void extractArguments(std::istream &ss, int &left, int &right, char &op){
    std::string left_s, right_s;
    ss >> left >> op >> right;

    cout << left << "op" << op << "right" << right << endl;
}

std::string removeSpaces(){
    std::cin >> std::noskipws;
    char c;
    std::string input;

    while(std::cin >> c){
        if(c != ' ')
            input += c;
    }

    return input;
}

bool hasMultipleOrNoOperators(const std::string& input){
    char c;
    int counter = 0;
    for(const auto &character : input.substr(1, input.length())){
        c = character;
        if(!std::isdigit(c) && c != '\n')
            counter++;
    }
    return counter != 1;
}

int main(int argc, char **argv){

    if(argc > 4 || argc == 3){
        cerr << "Invalid arguments. Expression does not meet the following requirement: number operator number. For multiplication, use '*'" << endl;
        exit(1);
    }

    char op;
    int left, right;

    std::stringstream ss;

    if(argc > 1){
        for (int i = 1; i < argc; ++i) {
            ss << std::string(argv[i]);
        }
    }else
        ss << removeSpaces();

    if(hasMultipleOrNoOperators(ss.str())){
        cerr << "You're dumb, not so many operators, please.";
        exit(5);
    }

    extractArguments(ss, left, right, op);

    if(!math::valid_op(op)){
        cerr << "No valid operator. Please use + - / or '*'.";
        exit(4);
    }

    cout << math::calc(op, left, right) << endl;

    return EXIT_SUCCESS;
}