//
// Created by Brandon Hernandez on 16.04.24.
//

#include "calc.h"
#include <iostream>

using std::cerr, std::endl;

namespace math {
    int calc(char op, int left, int right) {

        switch (op) {
            case '+': return left+right;
            case '-': return left-right;
            case '*': return left*right;
            case '/': return left/right;
            default: exit(3);
        }
    }

    bool valid_op(char op){
        return op == '+' || op == '*' || op == '/' || op == '-';
    }
}
