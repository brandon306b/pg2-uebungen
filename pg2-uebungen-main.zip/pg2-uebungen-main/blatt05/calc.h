//
// Created by Brandon Hernandez on 16.04.24.
//

#ifndef PG2_UEBUNGEN_CALC_H
#define PG2_UEBUNGEN_CALC_H

#endif //PG2_UEBUNGEN_CALC_H

namespace math{
    int calc(char op, int left, int right);
    bool valid_op(char op);
}