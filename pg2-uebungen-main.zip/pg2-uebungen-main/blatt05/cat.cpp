//
// Created by Brand on 15.04.2024.
//
#include "pg2.h"

void printUsage(){
    cout << "file path" << endl;
    cout << "file path -n to print out lines";
}

ifstream getFile(const string &fileName){
    ifstream file(fileName);
    if (!file.is_open()) {
        cerr << "Failed to open file: " << fileName << endl;
        exit(1);
    }
    return file;
}

void printFile(ifstream file){

    string line;
    while(getline(file, line))
        cout << line << endl;
}

void printFileWithLines(ifstream file){

    string line;
    int i = 1;

    while(getline(file, line)){
        cout << i << ": " << line << endl;
        i++;
    }

}

int main(int argc, char** argv){
    if(argc==1 || argc > 3 || argc == 3 && string(argv[2]) != "-n"){
        cerr << "Invalid usage. Type -h for help.";
        exit(1);
    }

    if(argc == 2 && string(argv[1]) == "-h")
        printUsage();

    if(argc == 2)
        printFile(getFile(string(argv[1])));

    else
        printFileWithLines(getFile(string(argv[1])));

    return 0;
}
