#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

int countLines(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Unable to open file: " << filename << std::endl;
        return -1;
    }

    int lineCount = 0;
    std::string line;
    while (std::getline(file, line)) {
        ++lineCount;
    }

    file.close();
    return lineCount;
}

void printFileContent(const std::string& filename, bool withLineNumbers) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Unable to open file: " << filename << std::endl;
        return;
    }

    int maxLineNumberWidth = 0;
    if (withLineNumbers) {
        int lineCount = countLines(filename);
        if (lineCount == -1) {
            return;
        }
        maxLineNumberWidth = std::to_string(lineCount).length();
    }

    std::string line;
    int lineNumber = 1;
    while (std::getline(file, line)) {
        if (withLineNumbers) {
            std::cout << std::setw(maxLineNumberWidth) << lineNumber << "  ";
        }
        std::cout << line << std::endl;
        ++lineNumber;
    }

    file.close();
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <filename> [-n]" << std::endl;
        return 1;
    }

    std::string filename = argv[1];
    bool withLineNumbers = false;

    if (argc == 3 && std::string(argv[2]) == "-n") {
        withLineNumbers = true;
    }

    printFileContent(filename, withLineNumbers);

    return 0;
}
