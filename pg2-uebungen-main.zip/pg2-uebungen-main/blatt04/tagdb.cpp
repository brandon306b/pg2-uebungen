//
// Created by Brand on 08.04.2024.
//
#include "pg2.h"

struct database{
    string entry;
    string content_separated_from_entry;
    vector <string> tags_separated_from_entry;
};

void printUsage(){
    cout << "To append an entry to the database, use tagdb -a tag1,tag2,...,tag3 content..." << endl;
    cout << "The appended content will look like this: tag1 , tag2 ,... , tag3 content ..." << endl;
    cout << "To search for an entry that contains ALL queried tags, use tagdb -q tag1,tag2" << endl;
}

string getFilePath(){

    const char* homeDir;
    #ifdef _WIN32
        homeDir = getenv("USERPROFILE");
    #else
        homeDir = getenv("HOME");
    #endif
    string filePath = string(homeDir) + "/tagdb.db";

    return filePath;
}

void appendToDatabase(int argc, char **argv){

    ofstream outputFile(getFilePath(), std::ios::app);

    if (!outputFile) {
        cerr << "Error: Unable to create or open the file!" << endl;
        exit(1);
    }

    string tag(argv[2]);
    string content(argv[3]);

    for(int i = 4; i<argc; i++){
        content.append(" ");
        content.append(argv[i]);
    }

    outputFile << tag << " " << content << endl;

    cout << "Entry: " << tag << " " << content << " has been added successfully!";

}

vector<string> getTagsFromEntry(const string &tags){
    vector <string> tagsFromEntry;
    stringstream ss(tags);
    string tag;
    while(getline(ss, tag, ',')){
        tagsFromEntry.push_back(tag);
    }

    return tagsFromEntry;
}

bool tagIsInEntry(const vector <string> &tags_from_entry, const string &userTag){
    for(auto &tag: tags_from_entry){
        if(tag == userTag) return true;
    }
    return false;
}

///improved version by phind
/*bool tagIsInEntry(const std::vector<std::string>& tags_from_entry, const std::string& userTag) {
    return std::find(tags_from_entry.begin(), tags_from_entry.end(), userTag) != tags_from_entry.end();
}*/

void queryDatabase(const string &userInputTags){
    ifstream inputFile(getFilePath());

    vector<database> entries;
    //vector<string> entries, tags_separated_from_entries;
    string line;

    while(getline(inputFile, line)){
        database entry;
        entry.entry = line;
        size_t pos = line.find(' ');
        entry.tags_separated_from_entry = getTagsFromEntry(line.substr(0, pos));
        entry.content_separated_from_entry = line.substr(pos+1, line.size());
        entries.push_back(entry);
    }

    stringstream ss(userInputTags);
    vector<string> tagInput;
    string tag;

    while(getline(ss, tag, ','))
        tagInput.push_back(tag);

    for(const auto &userTag: tagInput){
        for(auto it = entries.rbegin(); it != entries.rend(); ++it){
            if(!tagIsInEntry(it->tags_separated_from_entry, userTag))
                entries.erase(next(it).base());
        }
    }
    int iterator = 1;
    for(const auto &entry: entries){
        cout << iterator << ": " << entry.content_separated_from_entry << endl;
        iterator++;
    }

    if(entries.empty())
        cerr << "No entries with the specified tags were found" << endl;

}

int main(int argc, char** argv){
    if(argc==1) {
        cout << "No parameters given. Try using --help or -h for help." << endl;
        return 4;
    }

    if(argc == 2){
        if(string(argv[1]) == "-h" || string(argv[1]) == "--help")
            printUsage();
        else cout << "Invalid input. Try using --help or -h for help." << endl;
        return 2;
    }

    if(string(argv[1]) == "-a"){
        if(argc > 3)
            appendToDatabase(argc, argv);
        else
            cout << "Invalid input. Try using --help or -h for help." << endl;
    }
    else if(string(argv[1]) == "-q" && argc == 3)
        queryDatabase(string(argv[2]));
    else
        cout << "Invalid input. Try using --help or -h for help." << endl;

    return 0;
}