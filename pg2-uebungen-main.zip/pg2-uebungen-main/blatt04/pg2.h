#include <string>
#include <vector>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <map>
//#include <util>
#include <cstring>
#include <chrono>
#include <cmath>

using namespace std;