#include "png++/png.hpp"
using namespace png;

png::rgb_pixel color_map(float n, float max);