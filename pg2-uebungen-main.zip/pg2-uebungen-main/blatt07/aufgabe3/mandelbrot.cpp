//
// Created by Brandon Hernandez on 29.04.24.
//

#include "color.h"
#include "../complex-number.h"
using namespace std;

int steps(const complex_number& complex, int schranke, int max_it){
    int amount_steps = 0;
    complex_number c = 0; // z_0 = 0

    while(amount_steps < max_it && c.abs() <= 2 /*abs(c.imagteil()) <= 2 && abs(c.realteil()) <= 2*/){
        c *= c;
        c += complex;
        amount_steps++;
    }

    return amount_steps;
}
int main(int argc, char** argv){

    if(argc != 4){
        cerr << "Too many or too few arguments" << endl;
        return 1;
    }

    int w = stoi(argv[1]);
    int h = stoi(argv[2]);
    string output_filename(argv[3]);

    image<rgb_pixel> result(w, h);
    for(uint_32 y = 0; y < result.get_height(); ++y){
        for(uint_32 x = 0; x < result.get_width(); ++x){
            result[y][x] = rgb_pixel(255,255,255);
        }
    }

    int s = 2;
    int max_col = 2000;
    int amount_pixels = w * h;
    int counter = 1;

    for(int x= 0; x < w; ++x){
        for(int y = 0; y < h; ++y){
#pragma open parallel for
            double c_real = -2 + 4.0 / w * x;
            double c_imag = -2 + 4.0 / h * y;
            complex_number c(c_real, c_imag);
            int n = steps(c, s, max_col);
            result.set_pixel(x, y, color_map(n % max_col, max_col));
        }
        counter++;
        cout << h*counter << "/" << amount_pixels << " abgeschlossen" << endl;
    }
    result.write(output_filename);
}