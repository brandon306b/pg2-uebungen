#include "complex-number.h"

complex_number::complex_number(double re) : re(re), imag(0){}
complex_number::complex_number(double re, double imag) : re(re), imag(imag){}

const double &complex_number::realteil() const {
    return this->re;
}

const double &complex_number::imagteil() const {
    return this->imag;
}

complex_number complex_number::operator+=(const complex_number &other){
    this -> imag += other.imag;
    this -> re += other.re;
    return *this;
}

complex_number complex_number::operator-=(const complex_number &other) {
    this -> re -= other.re;
    this -> imag -= other.imag;
    return *this;
}

complex_number complex_number::operator*=(const complex_number &other) {
    double new_re = this->re * other.re +  this -> imag * other.imag * -1;
    double new_imag = this -> re * other.imag + this -> imag * other.re;
    re = new_re;
    imag = new_imag;
    return *this;
}

complex_number operator+(const complex_number &lhs, const complex_number &rhs){
    complex_number new_complex = lhs;
    return new_complex += rhs;
}

complex_number operator+(double real, complex_number &c){
    c.re += real;
    return c;
}

complex_number operator+(complex_number &c, double real){
    c.re += real;
    return c;
}

complex_number operator-(const complex_number &lhs, const complex_number &rhs){
    complex_number new_complex = lhs;
    return new_complex -= rhs;
}

complex_number operator*(const complex_number &lhs, const complex_number &rhs){
    complex_number new_complex = lhs;
    return new_complex *= rhs;
}

std::ostream & operator<<(std::ostream &out, const complex_number &c){
    return out << c.re << "+" << c.imag << "i";
}

double complex_number::abs() const {
    return sqrt(re*re+imag*imag);
}