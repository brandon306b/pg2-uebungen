//
// Created by Brand on 29.04.2024.
//
#include "png++/png.hpp"
#include "complex-number.h"
#include <string>

using namespace png;

complex_number generateNewComplexNumber(double r, double angle){
    complex_number c(r*cos(angle), r*sin(angle));
    return c;
}

int main(int argc, char **argv){
    if(argc != 4){
        cerr << "Too many or too few arguments" << endl;
        return 1;
    }

    int w = stoi(argv[1]);
    int h = stoi(argv[2]);
    string output_filename(argv[3]);

    image<rgb_pixel> result(w, h);

    for(uint_32 y = 0; y < result.get_height(); ++y){
        for(uint_32 x = 0; x < result.get_width(); ++x){
            result[y][x] = rgb_pixel(255,255,255);
        }
    }

    double r = 0.05;
    double angle = 0.2;
    double angle_step = 0.01;
    double r_step = 0.01;
    complex_number c = generateNewComplexNumber(r, angle);

    while(true){
        int x = w/2 + c.realteil();
        int y = h/2 + c.imagteil();
        cout << "x:" << x << " y:" << y << endl;
        if(x >= w || x < 0 || y >= h || y < 0)
            break;

        r += r_step;
        angle += angle_step;
        c = generateNewComplexNumber(r, angle);

        result[y][x] = rgb_pixel (0,0,0);

    }

    result.write(output_filename);
}