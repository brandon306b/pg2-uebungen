#include <iostream>
#include <cmath>
using namespace std;

class complex_number{
    double imag;
    double re;
public:
    complex_number(double re);
    complex_number(double re, double complex);
    const double& realteil() const;
    const double& imagteil() const;
    double abs() const;
    complex_number operator+=(const complex_number &other);
    complex_number operator-=(const complex_number &other);
    complex_number operator*=(const complex_number &other);


    friend complex_number operator+(double real, complex_number &c);
    friend complex_number operator+(complex_number &c, double real);
    friend std::ostream & operator<<(std::ostream &out, const complex_number &c);
};