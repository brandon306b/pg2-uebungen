//
// Created by Brandon Hernandez on 21.04.24.
//

#ifndef PG2_UEBUNGEN_DYNAMIC_ARRAY_H
#define PG2_UEBUNGEN_DYNAMIC_ARRAY_H

#include <iostream>

class dynamic_array {
    int* ptr;
    int size;
    int capacity;
    void reserve(unsigned int);

public:
    dynamic_array();
    dynamic_array(int);
    ~dynamic_array();
    int& at(int) const;
    void push(int);
    int getSize() const;
};



#endif //PG2_UEBUNGEN_DYNAMIC_ARRAY_H
