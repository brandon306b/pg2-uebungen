//
// Created by Brandon Hernandez on 22.04.24.
//
#include "png++/png.hpp"

using namespace std;

void convertToGrayscale(png::image< png::rgb_pixel > image) {
    for (png::uint_32 y = 0; y < image.get_height(); ++y) {
        for (png::uint_32 x = 0; x < image.get_width(); ++x) {
            png::rgb_pixel pixel = image.get_pixel(x, y);
            float avg = (pixel.red + pixel.green + pixel.blue) / 3.0;
            pixel.red = pixel.green = pixel.blue = (unsigned char) avg;
            image.set_pixel(x, y, pixel);
            // non-checking equivalent of image.set_pixel(x, y, ...);
        }
    }
    image.write("grayscale.png");
    cout << "Grayscale image generated" << endl;
}

void convertToGrayscaleUsingLuminance(png::image< png::rgb_pixel > image){
    for (png::uint_32 y = 0; y < image.get_height(); ++y) {
        for (png::uint_32 x = 0; x < image.get_width(); ++x) {
            png::rgb_pixel pixel = image.get_pixel(x, y);
            float luminance = (0.299f*pixel.red+0.587f*pixel.green+0.114f*pixel.blue) / 3.0f;
            pixel.red = pixel.green = pixel.blue = (unsigned char) luminance;
            image.set_pixel(x, y, pixel);
            // non-checking equivalent of image.set_pixel(x, y, ...);
        }
    }
    image.write("luminance.png");
    cout << "Luminance image generated" << endl;
}

int main(){
    png::image< png::rgb_pixel > image ("media.png");
    convertToGrayscale(image);
    convertToGrayscaleUsingLuminance(image);

    return 0;
}
