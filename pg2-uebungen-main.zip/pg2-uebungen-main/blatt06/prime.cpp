#include "dynamic_array.h"
#include <iostream>

bool isPrime(int n, const dynamic_array& primes) {
    for (int i = 0; i < primes.getSize(); ++i) {
        if (n % primes.at(i) == 0) {
            return false;
        }
    }
    return true;
}

void generatePrimes(dynamic_array& primes, int maxValue) {

    if (primes.getSize() == 0) {
        primes.push(2);
    }

    for (int i = primes.at(primes.getSize() - 1) + 1; i <= maxValue; ++i) {
        if (isPrime(i, primes)) {
            primes.push(i);
            std::cout << i << " wurde gefunden" << std::endl;
        }
    }
}

int main(int argc, char** argv) {
    int maxValue(std::stoi(argv[1]));

    dynamic_array primes;

    generatePrimes(primes, maxValue);

    std::cout << "Primzahlen bis " << maxValue << ":\n";
    for (int i = 0; i < primes.getSize(); ++i) {
        std::cout << primes.at(i) << " ";
    }
    std::cout << std::endl;

    return 0;
}
