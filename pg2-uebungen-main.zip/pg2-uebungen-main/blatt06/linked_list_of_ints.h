//
// Created by Brandon Hernandez on 22.04.24.
//

#ifndef PG2_UEBUNGEN_LINKED_LIST_OF_INTS_H
#define PG2_UEBUNGEN_LINKED_LIST_OF_INTS_H

class linked_list_of_ints {
    struct node{
        node* next;
        int value;
        node();
    };
    node* head;
    node* current_position;
    int size;
public:
    linked_list_of_ints();
    ~linked_list_of_ints();

    //list management
    void prepend(const int number);
    void append(const int number);
    void append_at(const int number, int at);
    node* create_node(const int number);
    bool is_valid_position(int at);
    void remove_current();
    void remove_at(const int at);
    void remove_with_value(const int value);
    void remove_first_occurrence(const int value);

    //list traversal
    void start();
    bool at_valid_position();
    void next();
    const int current_value();
    const int getSize();
};


#endif //PG2_UEBUNGEN_LINKED_LIST_OF_INTS_H
