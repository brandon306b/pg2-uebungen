//
// Created by Brandon Hernandez on 21.04.24.
//

#include "dynamic_array.h"
using std::cout, std::endl;

dynamic_array::dynamic_array() : size(0), capacity(0){
    ptr = nullptr;
}

dynamic_array::dynamic_array(int init_size) : size(0), capacity(init_size){
    ptr = new int[init_size];
}

dynamic_array::~dynamic_array() {
    if(ptr)
        delete[] ptr;
}

int &dynamic_array::at(const int i) const{
    if(i >= size)
        throw std::out_of_range("Index out of range!");
    return ptr[i];
}

void dynamic_array::push(int x) {
    if(size == capacity)
        reserve(capacity*2);

    ptr[size] = x;
    size++;
}

void dynamic_array::reserve(unsigned int n){
    if(capacity > n){
        std::cerr << "Reserving less than capacity is illegal" << std::endl;
        return;
    }
    ptr = (int*)realloc(ptr, n);
}

int dynamic_array::getSize() const {
    return size;
}