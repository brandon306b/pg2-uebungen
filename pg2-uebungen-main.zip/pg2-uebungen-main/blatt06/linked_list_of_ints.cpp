//
// Created by Brandon Hernandez on 22.04.24.
//

#include "linked_list_of_ints.h"
#include <cassert>

linked_list_of_ints::node::node(){
    next = nullptr;
}

linked_list_of_ints::linked_list_of_ints(){
    current_position = nullptr;
    head = nullptr;
    size = 0;
}

linked_list_of_ints::~linked_list_of_ints(){
    while(head){
        node *to_delete = head;
        head = head -> next;
        delete to_delete;
    }
}

linked_list_of_ints::node* linked_list_of_ints::create_node(const int number) {
    node *new_node = new node;
    new_node -> value = number;
    return new_node;
}

void linked_list_of_ints::append(const int number) {
    node *to_append = create_node(number);
    if(!head)
        head = to_append;
    else{
        node *run = head;
        while(run -> next)
            run = run -> next;
        run -> next = to_append;
    }
    size++;
}

void linked_list_of_ints::prepend(const int number) {
    node *to_prepend = create_node(number);
    if(!head)
        head = to_prepend;
    else{
        to_prepend -> next = head;
        head = to_prepend;
    }
    size++;
}

void linked_list_of_ints::append_at(const int number, int at) {
    node *to_append = create_node(number);
    assert(is_valid_position(at));
        node *run = head;
        for (int i = 0; i < at; ++i)
            run = run -> next;
        to_append -> next = run -> next; //new successor of appended element is the element at index at
        run -> next = to_append;
}

bool linked_list_of_ints::is_valid_position(int at) {
    return size > at; //index starting at 0
}

void linked_list_of_ints::remove_current() {
    assert(at_valid_position());
    if (current_position == head) {
        head = head->next;
        delete current_position;
        current_position = head;
    }
    else {
        node *run = head;
        while (run->next != current_position) run = run->next;
        run->next = current_position->next;
        delete current_position;
        current_position = run->next;
    }
}

void linked_list_of_ints::remove_at(const int at) {
    assert(is_valid_position(at));
    node *run = head;
    for (int i = 0; i < at; ++i)
        run = run -> next;
    current_position = run -> next;
    remove_current();
    size--;
}

void linked_list_of_ints::remove_with_value(const int value) {
    node *run = head;
    while(run){
        if(run -> value == value){
            run = current_position;
            remove_current();
        }
    }
}

void linked_list_of_ints::remove_first_occurrence(const int value) {
    node *run = head;
    while(run){
        if(run -> value == value){
            run = current_position;
            remove_current();
            break;
        }
    }
}

//list traversal
void linked_list_of_ints::start() {
    current_position = head;
}

bool linked_list_of_ints::at_valid_position() {
    return current_position != nullptr;
}

void linked_list_of_ints::next() {
    assert(at_valid_position());
    current_position = current_position -> next;
}

const int linked_list_of_ints::current_value() {
    assert(at_valid_position());
    return current_position -> value;
}

const int linked_list_of_ints::getSize() {
    return size;
}


