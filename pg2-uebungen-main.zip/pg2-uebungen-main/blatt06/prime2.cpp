#include "linked_list_of_ints.h"
#include <iostream>
using namespace std;

bool isPrime(int n, linked_list_of_ints& primes) {
    primes.start();
    while (primes.at_valid_position()) {
        if (n % primes.current_value() == 0) {
            return false;
        }
        primes.next();
    }
    return true;
}

void generatePrimes(linked_list_of_ints& primes, int maxValue) {
    // Stellen Sie sicher, dass 2 im Array ist
    if (primes.getSize() == 0) {
        primes.append(2);
    }
    primes.start();
    for (int i = primes.current_value() + 1; i <= maxValue; ++i) {
        if (isPrime(i, primes)) {
            primes.append(i);
        }
    }
}

int main(int argc, char** argv) {
    int maxValue(std::stoi(argv[1]));

    linked_list_of_ints primes;
    generatePrimes(primes, maxValue);

    std::cout << "Primzahlen bis " << maxValue << ":\n";
    primes.start();
    while (primes.at_valid_position()) {
        std::cout << primes.current_value() << " ";
        primes.next();
    }
    std::cout << std::endl;

    return 0;
}
